package hus.oop.statistics;

public class Node {
    public double data;
    public Node next;

    public Node(double data) {
        this.data = data;
        this.next = null;
    }
}
