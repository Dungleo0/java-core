package hus.oop.studentmanager;


public interface MyStudentComparable {
    int compareTo(Student another);
}
