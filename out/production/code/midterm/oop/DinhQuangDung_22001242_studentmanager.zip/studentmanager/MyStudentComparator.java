package hus.oop.studentmanager;

public interface MyStudentComparator {
    int compare(Student left, Student right);
}
